package guiPackV2_3;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import org.apache.pdfbox.io.IOUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.apache.xmlbeans.impl.piccolo.io.FileFormatException;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
//"src/report.xlsx"
@SuppressWarnings("serial")
public class StaticKeyPdfGui extends JFrame {
		// Reads doc docx 
		// reads tables
		// reads pdf
		// has help button
		// Finalized as jar
	

	private JPanel contentPane;
	private JTextField currentDirField;
	private JTextField textField_0;
	private JTextField textField_3;
	private JTextField textField_6;
	private JTextField textField_1;
	private JTextField textField_4;
	private JTextField textField_7;
	private JTextField textField_2;
	private JTextField textField_5;
	private JTextField textField_8;
	private JTextField reportLog;
	String dir;
	static String reportpath;
	private JTextField keyNums;
	TextArea EligibleReport;
	List<String> eligible;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StaticKeyPdfGui frame = new StaticKeyPdfGui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	
	
	public StaticKeyPdfGui() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(StaticKeyPdfGui.class.getResource("/guiPackV2_3/resumeOwl.png")));
		setBackground(new Color(255, 255, 255));
		setForeground(new Color(0, 0, 204));
		//setIconImage(Toolkit.getDefaultToolkit().getImage(StaticKeyPdfGui.class.getResource("/guiPackV2_3/resumeOwl.png")));
		//setIconImage(Toolkit.getDefaultToolkit().getImage(StaticKeyPdfGui.class.getResource("/guiPackV2_3/index.icon.jpg")));//Constructor
		setTitle("RayZume");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 460, 600);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(255, 255, 255));
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton getDirBtn = new JButton("Browse Directory");
		getDirBtn.setForeground(new Color(0, 0, 153));
		getDirBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
		getDirBtn.setBounds(23, 58, 165, 23);
		contentPane.add(getDirBtn);
		
		currentDirField = new JTextField();
		currentDirField.setForeground(new Color(51, 0, 204));
		currentDirField.setBackground(UIManager.getColor("Button.background"));
		currentDirField.setEditable(false);
		currentDirField.setBounds(198, 59, 205, 20);
		contentPane.add(currentDirField);
		currentDirField.setColumns(10);
		
		JLabel keywordLbl = new JLabel("Enter Number of Keywords");
		keywordLbl.setForeground(new Color(0, 153, 204));
		keywordLbl.setFont(new Font("SansSerif", Font.BOLD, 11));
		keywordLbl.setBounds(23, 92, 170, 11);
		contentPane.add(keywordLbl);
		
		textField_0 = new JTextField();
		textField_0.setForeground(new Color(51, 0, 204));
		textField_0.setBackground(new Color(255, 255, 255));
		textField_0.setBounds(34, 155, 86, 20);
		contentPane.add(textField_0);
		textField_0.setColumns(10);
		
		JLabel keyNum1 = new JLabel("1.");
		keyNum1.setForeground(new Color(51, 153, 204));
		keyNum1.setFont(new Font("Tahoma", Font.BOLD, 11));
		keyNum1.setHorizontalAlignment(SwingConstants.CENTER);
		keyNum1.setBounds(0, 155, 46, 14);
		contentPane.add(keyNum1);
		
		textField_3 = new JTextField();
		textField_3.setForeground(new Color(51, 0, 204));
		textField_3.setBackground(new Color(255, 255, 255));
		textField_3.setColumns(10);
		textField_3.setBounds(34, 186, 86, 20);
		contentPane.add(textField_3);
		
		JLabel label = new JLabel("4.");
		label.setForeground(new Color(51, 153, 204));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("Tahoma", Font.BOLD, 11));
		label.setBounds(0, 186, 46, 14);
		contentPane.add(label);
		
		textField_6 = new JTextField();
		textField_6.setForeground(new Color(51, 0, 204));
		textField_6.setBackground(new Color(255, 255, 255));
		textField_6.setColumns(10);
		textField_6.setBounds(34, 217, 86, 20);
		contentPane.add(textField_6);
		
		JLabel label_1 = new JLabel("7.");
		label_1.setForeground(new Color(51, 153, 204));
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_1.setBounds(0, 217, 46, 14);
		contentPane.add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setForeground(new Color(51, 0, 204));
		textField_1.setBackground(new Color(255, 255, 255));
		textField_1.setColumns(10);
		textField_1.setBounds(187, 155, 86, 20);
		contentPane.add(textField_1);
		
		JLabel label_2 = new JLabel("2.");
		label_2.setForeground(new Color(51, 153, 204));
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_2.setBounds(151, 155, 46, 14);
		contentPane.add(label_2);
		
		textField_4 = new JTextField();
		textField_4.setForeground(new Color(51, 0, 204));
		textField_4.setBackground(new Color(255, 255, 255));
		textField_4.setColumns(10);
		textField_4.setBounds(187, 186, 86, 20);
		contentPane.add(textField_4);
		
		JLabel label_3 = new JLabel("5.");
		label_3.setForeground(new Color(51, 153, 204));
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_3.setBounds(151, 186, 46, 14);
		contentPane.add(label_3);
		
		textField_7 = new JTextField();
		textField_7.setForeground(new Color(51, 0, 204));
		textField_7.setBackground(new Color(255, 255, 255));
		textField_7.setColumns(10);
		textField_7.setBounds(187, 217, 86, 20);
		contentPane.add(textField_7);
		
		JLabel label_4 = new JLabel("8.");
		label_4.setForeground(new Color(51, 153, 204));
		label_4.setHorizontalAlignment(SwingConstants.CENTER);
		label_4.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_4.setBounds(151, 217, 46, 14);
		contentPane.add(label_4);
		
		textField_2 = new JTextField();
		textField_2.setForeground(new Color(51, 0, 204));
		textField_2.setBackground(new Color(255, 255, 255));
		textField_2.setColumns(10);
		textField_2.setBounds(338, 155, 86, 20);
		contentPane.add(textField_2);
		
		JLabel label_5 = new JLabel("3.");
		label_5.setForeground(new Color(51, 153, 204));
		label_5.setHorizontalAlignment(SwingConstants.CENTER);
		label_5.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_5.setBounds(306, 155, 46, 14);
		contentPane.add(label_5);
		
		textField_5 = new JTextField();
		textField_5.setForeground(new Color(51, 0, 204));
		textField_5.setBackground(new Color(255, 255, 255));
		textField_5.setColumns(10);
		textField_5.setBounds(338, 186, 86, 20);
		contentPane.add(textField_5);
		
		JLabel label_6 = new JLabel("6.");
		label_6.setForeground(new Color(51, 153, 204));
		label_6.setHorizontalAlignment(SwingConstants.CENTER);
		label_6.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_6.setBounds(306, 186, 46, 14);
		contentPane.add(label_6);
		
		textField_8 = new JTextField();
		textField_8.setForeground(new Color(51, 0, 204));
		textField_8.setBackground(new Color(255, 255, 255));
		textField_8.setColumns(10);
		textField_8.setBounds(338, 217, 86, 20);
		contentPane.add(textField_8);
		
		JLabel label_7 = new JLabel("9.");
		label_7.setForeground(new Color(51, 153, 204));
		label_7.setHorizontalAlignment(SwingConstants.CENTER);
		label_7.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_7.setBounds(306, 217, 46, 14);
		contentPane.add(label_7);
		
		JButton reportGenBtn = new JButton("Generate Report");
		reportGenBtn.setForeground(new Color(0, 0, 153));
		reportGenBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
		reportGenBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e2) {
				String[] keywords = {textField_0.getText(),textField_1.getText(),textField_2.getText(),textField_3.getText(),textField_4.getText(),
						textField_5.getText(),textField_6.getText(),textField_7.getText(),textField_8.getText()};
				
				
				int many = Integer.parseInt(keyNums.getText());
				System.out.println("in the constructor many is : "+many);
				String address = dir;
				System.out.println(address+": This is address of folder"+many);
				try {
					BeginsFromHere(keywords, address, many);
				} catch (InvalidFormatException e) {					
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} 
				
				System.out.println("The Number of keywords is: "+keywords.length);
			}
		});
		reportGenBtn.setBounds(23, 264, 174, 23);
		contentPane.add(reportGenBtn);
		
		JButton reportOpen = new JButton("Open Report");
		reportOpen.setForeground(new Color(0, 0, 153));
		reportOpen.setFont(new Font("SansSerif", Font.BOLD, 12));
		reportOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					
			        if ((new File(reportpath)).exists()) {
			            Process p = Runtime
			               .getRuntime()			               
			               .exec("rundll32 url.dll,FileProtocolHandler "+reportpath);
			            p.waitFor();			           

			        } else {			        	
			            System.out.println("File does not exist");

			        }

			      } catch (Exception ex) {
			        ex.printStackTrace();
			      }
				
				
			}
		});
		reportOpen.setBounds(207, 264, 111, 23);
		contentPane.add(reportOpen);
		
		JButton resetBtn = new JButton("Reset");
		resetBtn.setForeground(new Color(0, 0, 153));
		resetBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
		resetBtn.addActionListener(new ActionListener() {

			//@Override
			public void actionPerformed(ActionEvent e) {
				textField_0.setText(null);
				textField_1.setText(null);
				textField_2.setText(null);
				textField_3.setText(null);
				textField_4.setText(null);
				textField_5.setText(null);
				textField_6.setText(null);
				textField_7.setText(null);
				textField_8.setText(null);
				keyNums.setText(null);
				currentDirField.setText(null);
				reportLog.setText(null);
				EligibleReport.setText(null);
				
				
			}
			
		});

		resetBtn.setBounds(103, 538, 96, 23);
		contentPane.add(resetBtn);
		
		reportLog = new JTextField();
		reportLog.setForeground(new Color(51, 0, 204));
		reportLog.setBackground(UIManager.getColor("Button.background"));
		reportLog.setEditable(false);
		reportLog.setBounds(23, 295, 175, 20);
		contentPane.add(reportLog);
		reportLog.setColumns(10);
		
		JLabel lblFileReader = new JLabel("");
		lblFileReader.setIcon(new ImageIcon(StaticKeyPdfGui.class.getResource("/guiPackV2_3/logo1.jpg")));
		lblFileReader.setBackground(new Color(0, 0, 0));
		lblFileReader.setForeground(new Color(0, 0, 205));
		lblFileReader.setFont(new Font("Palatino Linotype", Font.BOLD, 20));
		lblFileReader.setHorizontalAlignment(SwingConstants.CENTER);
		lblFileReader.setBounds(27, 18, 111, 23);
		contentPane.add(lblFileReader);
		
		keyNums = new JTextField();
		keyNums.setForeground(new Color(51, 0, 204));
		keyNums.setBackground(new Color(255, 255, 255));
		keyNums.setBounds(198, 87, 40, 20);
		contentPane.add(keyNums);
		keyNums.setColumns(10);
		
		JLabel keywordfieldsLbl = new JLabel("Enter Keywords");
		keywordfieldsLbl.setForeground(new Color(0, 153, 204));
		keywordfieldsLbl.setFont(new Font("SansSerif", Font.BOLD, 11));
		keywordfieldsLbl.setBounds(23, 131, 134, 14);
		contentPane.add(keywordfieldsLbl);
		
		EligibleReport = new TextArea();
		EligibleReport.setFont(new Font("Calibri", Font.PLAIN, 13));
		EligibleReport.setBackground(new Color(255, 255, 255));
		EligibleReport.setForeground(new Color(0, 102, 51));
		EligibleReport.setBounds(23, 336, 401, 196);
		contentPane.add(EligibleReport);
		
		JButton filterBtn = new JButton("Filter");
		filterBtn.setForeground(new Color(0, 0, 153));
		filterBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
		filterBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				//Excel Iterator
				try{
				String fileaddress1 = reportpath;
				FileInputStream fish = new FileInputStream(fileaddress1);
				@SuppressWarnings("resource")
				XSSFWorkbook workbook = new XSSFWorkbook(fish);    
				XSSFSheet sheet = workbook.getSheetAt(0);
				int rownum = 1;
				int cellNumber = 1;
				
				eligible = new ArrayList<String>();
				Row row = sheet.getRow(rownum);
				Cell cell = row.getCell(cellNumber);
				DataFormatter dataFormatter = new DataFormatter();
				 
				System.out.println("\n\nIterating over Rows and Columns using for-each loop\n");
			        
				int rownumber;
				int manyOne = Integer.parseInt(keyNums.getText())+1;
				
				
				for (Row row1: sheet) {
					int counterr=0;   
					for(Cell cell1: row1) {
			                String cellValue = dataFormatter.formatCellValue(cell1);
			                
			                	if(! cellValue.equals("0")){
			                		              	
			                		counterr++;
			                	}
			                	if(counterr>=manyOne){
			                		rownumber=row1.getRowNum();
			                		Row row2=sheet.getRow(rownumber);
			                		Cell cell2=row2.getCell(0);
			                		String name = dataFormatter.formatCellValue(cell2);
			                		System.out.print(name + "\n");
			                		eligible.add(name);
			                	}
					
			                	
			                }
					
			            
			            }
				for(String elig:eligible){
					
					 EligibleReport.append(elig+"\n");
				}
			           
			      
			            
			            
				}catch(Exception ella){
					System.err.println(ella);
			           
			        }
				
			} 
				//Excel Iterator
				
				
			
	});
		filterBtn.setBounds(328, 264, 96, 23);
		contentPane.add(filterBtn);
		
		JButton helpBtn = new JButton("Help");
		helpBtn.setForeground(new Color(0, 0, 153));
		helpBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
		helpBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				HelpFrame.stan();
			}
		});
		helpBtn.setBounds(260, 538, 89, 23);
		contentPane.add(helpBtn);
		
		JLabel lblOwlsearch = new JLabel("OwlSearch");
		lblOwlsearch.setForeground(new Color(51, 153, 255));
		lblOwlsearch.setHorizontalAlignment(SwingConstants.CENTER);
		lblOwlsearch.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
		lblOwlsearch.setBounds(274, 11, 150, 30);
		contentPane.add(lblOwlsearch);
		
		getDirBtn.addActionListener(new ActionListener() {			
	        // @Override
	         public void actionPerformed(ActionEvent e1) {
	            System.out.println("file chooser button Action");
	            JFileChooser fc=new JFileChooser();
				fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				//int response=fc.showOpenDialog(DirectoriesOnly.this);
				
				if(fc.showOpenDialog(null)==JFileChooser.APPROVE_OPTION)
					currentDirField.setText(fc.getSelectedFile().toString());
				
				dir=fc.getSelectedFile().toString();
				System.out.println("the Directory name is : "+ dir);
				
	         }
	});
		
		
	}


	protected void BeginsFromHere(String[] keywords, String dir2, int many) throws InvalidFormatException, IOException {
		
		
		
		File folder = new File(dir2); //ALL DOCX RESUME FILES 
		String newDir = dir2 + folder.separator+"report";
		File fodder = new File(newDir);
		fodder.mkdir();
		
		String reportPath = newDir+fodder.separator+"report.xlsx";
		File reporter = new File(reportPath);
		reporter.createNewFile();
		//System.out.println("******** "+reportPath+" *********");
		reportpath = reportPath;
		
		
		
		File[] listOfFiles = folder.listFiles();
		
		List<String> listOFiles = FolderIterator(listOfFiles);
		int noOfFiles = listOFiles.size();
		
		System.out.println("the number of files is :"+noOfFiles+"\n");
		for(int h=0;h<many;h++){
			System.out.println(keywords[h]);
		}
		System.out.println("The number of keywords is : "+many+"\n");
		
		
		XSSFWorkbook workbook = new XSSFWorkbook();    
		XSSFSheet sheet = workbook.createSheet("sheet1");
		
		SendDataToExcel(listOFiles,workbook, sheet);
		SendKeyDataToExcel(keywords, workbook, sheet, many);
		ParseFile(listOfFiles, keywords,noOfFiles,many); //read the document
		
		
	}


	private static void  ParseFile(File[] listOfFiles, String[] words, int num, int many) throws InvalidFormatException, IOException {
		
		XWPFDocument xdoc = null;
		int noOfKeywords = many;
		int rownum = 1;
		for (File file : listOfFiles) {
    	try
        {    		    		
        	//Iterate for files inside the folder
        	
	    	    if (file.isFile()) {  
	    	    	String fileN = file.getName();
	    	    	String fileAddress = file.getAbsolutePath(); //Address of the file
	    	    	FileInputStream fis = new FileInputStream(fileAddress);
	    	    	xdoc = new XWPFDocument(OPCPackage.open(fis));
	    	    	rownum = WordCountOutput(xdoc, words,fileN, rownum, noOfKeywords);
	    	    	//System.out.println("The row number in parsefile is : "+rownum);
		 		}
        	
        }catch (Exception e1)
        {
        	try{
        		if (file.isFile()) {  
        	
        		
    	    	String fileN = file.getName();
    	    	String fileAddress = file.getAbsolutePath(); //Address of the file
    	    	
    	    	FileInputStream fis = new FileInputStream(fileAddress);
    	    	HWPFDocument doc = new HWPFDocument(fis);
    	    	rownum = WordDocCountOutput(doc, words,fileN, rownum, noOfKeywords);
	 		}
        	}catch(Exception e2){
        		if (file.isFile()) {  
                            		
        	    	String fileN = file.getName();
        	    	String fileAddress = file.getAbsolutePath(); //Address of the file
        	    	
        	    	FileInputStream fis = new FileInputStream(fileAddress);
        	    	 byte[] thePDFFileBytes = readFileAsBytes(fileAddress);
        	         PDDocument pddDoc = PDDocument.load(thePDFFileBytes);
        	         rownum = pdfCountOutput(pddDoc,words,fileN, rownum, noOfKeywords);
        	}
        }}}
}

	
	private static int pdfCountOutput(PDDocument pddDoc, String[] keywords, String fileN, int rowNumber, int noOfkeywords) throws IOException, EncryptedDocumentException, InvalidFormatException {
		try {
			InputStream inp = new FileInputStream(reportpath);
			Workbook wb = WorkbookFactory.create(inp);
			Sheet sheet1 = wb.getSheet("sheet1");
			//System.out.println("The row number in word count method is : "+rowNumber);
			Row row = sheet1.getRow(rowNumber);
			int cellNumber = 1;
			int[] countArray = new int[keywords.length];
			int j = 0, m ;
			PDFTextStripper reader = new PDFTextStripper();
			String pageText = reader.getText(pddDoc);
			
			
			for(int k=0 ; k<noOfkeywords ; k++){//for(String key : words2) {
				
				Cell cell = row.createCell(cellNumber);
				
				int count=0;				
		
								
					String[]  words = pageText.split("\\s+");
				    	for (m = 0; m < words.length; m++) {					
								if(words[m].toLowerCase().contains(keywords[k].toLowerCase())){
				 					count++;
									} 					
						 			}	
						 				countArray[j]=count;
						 			
						 			
						
						//System.out.println(count+" * "+key+" in the file :"+fileName);
						cell.setCellValue(count);
						cellNumber++;
						
						
						FileOutputStream fileOut = new FileOutputStream(reportpath);
					    wb.write(fileOut);
					    fileOut.close();
					    
					  }
			j++;
			rowNumber++;
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return rowNumber;
	
	}

	private static byte[] readFileAsBytes(String filePath) throws IOException {
        FileInputStream inputStream = new FileInputStream(filePath);
        return IOUtils.toByteArray(inputStream);
}
	
	
	@SuppressWarnings("resource") //Does not need table iterators.
	//This method parses .doc files	
	private static int WordDocCountOutput(HWPFDocument realDoc,String[] words2, String fileN, int rowNumber , int noOfkeywords ) throws IOException, EncryptedDocumentException, InvalidFormatException {
			try {
				InputStream inp = new FileInputStream(reportpath);
				Workbook wb = WorkbookFactory.create(inp);
				Sheet sheet1 = wb.getSheet("sheet1");
				//System.out.println("The row number in word count method is : "+rowNumber);
				Row row = sheet1.getRow(rowNumber);
				int cellNumber = 1;
				int[] countArray = new int[words2.length];
				int j = 0 ;
				WordExtractor we = new WordExtractor(realDoc);
				
				
				for(int k=0 ; k<noOfkeywords ; k++){//for(String key : words2) {
					
					Cell cell = row.createCell(cellNumber);
					
					int count=0;
					String[] paragraphs = we.getParagraphText();
					for (String para : paragraphs) {
								
									//System.out.println("The paragraph text is *******"+paragraph.getText());
									
									String[] words = para.toString().split("\\s+");
							 				for (int i = 0; i < words.length; i++) {					
							 					if(words[i].toLowerCase().contains(words2[k].toLowerCase())){
									 					count++;
								 					}						 					
							 			}	
							 				countArray[j]=count;
							 			
							 			}
							
							//System.out.println(count+" * "+key+" in the file :"+fileName);
							cell.setCellValue(count);
							cellNumber++;
							
							
							FileOutputStream fileOut = new FileOutputStream(reportpath);
						    wb.write(fileOut);
						    fileOut.close();
						    
						  }
				j++;
				rowNumber++;
				
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			return rowNumber;
		}
		

	private static int WordCountOutput(XWPFDocument realDoc, String[] keywords, String fileName, int rowNumber, int noOfkeywords) throws IOException, EncryptedDocumentException, InvalidFormatException {
		try {
			InputStream inp = new FileInputStream(reportpath);
			Workbook wb = WorkbookFactory.create(inp);
			Sheet sheet1 = wb.getSheet("sheet1");
			//System.out.println("The row number in word count method is : "+rowNumber);
			Row row = sheet1.getRow(rowNumber);
			int cellNumber = 1;
			int[] countArray = new int[noOfkeywords];
			int j = 0 ;
			for(int k=0 ; k < noOfkeywords ; k++){//for(String key : keywords) {
				
				Cell cell = row.createCell(cellNumber);
				
				int count=0;
				 try { 
			    		
			           
			          
			            if(!(fileName.endsWith(".doc") || fileName.endsWith(".docx"))) { 
			                    throw new FileFormatException(); 
			            } else { 
			            
			          
			                    
			                    List<XWPFTable> table = realDoc.getTables();         
			                    
			                    for (XWPFTable xwpfTable : table) { 
								List<XWPFTableRow> roww = xwpfTable.getRows(); 
								for (XWPFTableRow xwpfTableRow : roww) { 
								        List<XWPFTableCell> celll = xwpfTableRow.getTableCells(); 
								        for (XWPFTableCell xwpfTableCell : celll) { 
							                if(xwpfTableCell!=null){ 
							                	String content = xwpfTableCell.getText();
							                	String[] wordss = content.split("\\s+");
							                	for (int jj = 0; jj < wordss.length; jj++) {					
								 					if(wordss[jj].toLowerCase().contains(keywords[k].toLowerCase())){
										 					count++;
									 					}
							                		//System.out.println(content+"\n");
							                	}
					                        List<XWPFTable> itable = xwpfTableCell.getTables(); 
						                        if(itable.size()!=0) { 
						                        	for (XWPFTable xwpfiTable : itable) { 
					                                    List<XWPFTableRow> irow = xwpfiTable.getRows(); 
					                                    for (XWPFTableRow xwpfiTableRow : irow) { 
				                                            List<XWPFTableCell> icell = xwpfiTableRow.getTableCells(); 
				                                            for (XWPFTableCell xwpfiTableCell : icell) { 
				                                                if(xwpfiTableCell!=null){   
				                                                	content = xwpfTableCell.getText();
				                                                	String [] swords = content.split("\\s+");
				            						 				for (int i = 0; i < swords.length; i++) {					
				            						 					if(swords[i].toLowerCase().contains(keywords[k].toLowerCase())){
				            								 					count++;
				            							 					}
				            					                		//System.out.println(content+"\n");
				                                                        //System.out.println(xwpfiTableCell.getText()+"\n"); 
				                                                }} 
			                                                } 
					                                        } 
							                                } 
						                        } 
								                } 
								        } 
								} 
			                    } 
			                   // System.out.println("The count of java is: "+count);
			            }
			                    
			    } catch(FileFormatException e1) { 
			            e1.printStackTrace(); 
			    } catch (IOException e) { 
			            e.printStackTrace(); 
			    } 
			    	
				
				
				
				
				
				
				
				
				
				
				Iterable<XWPFParagraph> paragraphList = realDoc.getParagraphs();
						for (XWPFParagraph paragraph : paragraphList) {
															
								String[] words = paragraph.getText().split("\\s+");
						 				for (int i = 0; i < words.length; i++) {					
						 					if(words[i].toLowerCase().contains(keywords[k].toLowerCase())){
								 					count++;
							 					}
						 				
						 			}	
						 				countArray[j]=count;
						 			
						 			}
						
						//System.out.println(count+" * "+key+" in the file :"+fileName);
						cell.setCellValue(count);
						cellNumber++;
						
						
						FileOutputStream fileOut = new FileOutputStream(reportpath);
					    wb.write(fileOut);
					    fileOut.close();
					    
					  }
			j++;
			rowNumber++;
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return rowNumber;
	}

	
	private void SendKeyDataToExcel(String[] keywords, XSSFWorkbook workbook3, XSSFSheet sheet3, int number) {
		 try
	        {    
			     //XSSFWorkbook workbook = new XSSFWorkbook(); 		           
			     //XSSFSheet sheet = workbook.createSheet("sheet1");// creating a blank sheet
			     
				  int colnum = 1;
				  Row row = sheet3.createRow(0);
			      for (int i=0; i<number ; i++)//String(String fila : keywords){
			         {
			    	  Cell cell = row.createCell(colnum++);
			          cell.setCellValue(keywords[i]);
			         }                   
			    
		         FileOutputStream out = new FileOutputStream(new File(reportpath)); // file name with path
		         workbook3.write(out);
		         out.close();
			     } 
			     catch (Exception e) 
			     {
			         e.printStackTrace();
			     }
			reportLog.setText("Report Generated");
			
		
	}


	private void SendDataToExcel(List<String> resumeFile, XSSFWorkbook workbook2, XSSFSheet sheet2) {
		try
        {    		     
			  int rownum = 1;
		      for (String fila : resumeFile){
		         Row row = sheet2.createRow(rownum++);
		         createList(fila, row);
		         }                   
		    
	         FileOutputStream out = new FileOutputStream(new File(reportpath)); // file name with path
	         workbook2.write(out);
	         out.close();
		     } 
		     catch (Exception e) 
		     {
		         e.printStackTrace();
		     }
	 	 
		
	
		
	}


	private void createList(String fil, Row row) {
		   Cell cell = row.createCell(0);
	        cell.setCellValue(fil);
		
	}


	@SuppressWarnings("unused")
	private List<String> FolderIterator(File[] listOfFiles) {
		List<String> resumeFile = new LinkedList<String>();
		
    	try
        {
        	//Iterate for files inside the folder
        	for (File file : listOfFiles) {
	    	    if (file.isFile()) {
	    	    	resumeFile.add(file.getName());
	    	    	//System.out.println("\n++++++"+resumeFile+"+++++++\n");	    	    	  	    		
	    	    	String fileAddress = file.getAbsolutePath(); //Address of the file
	    	    	//FileInputStream fis = new FileInputStream(fileAddress);
		 				 					
		 		}
        	}
        	System.out.println("\n++++++"+resumeFile+"+++++++\n");	    	    	  	    		
	    	
        }catch (Exception e)
        {
            e.printStackTrace();
        }
	
	return resumeFile;
	}
}