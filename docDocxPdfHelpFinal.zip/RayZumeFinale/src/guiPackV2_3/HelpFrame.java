package guiPackV2_3;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.JTextPane;
import java.awt.Color;
import java.awt.Font;

public class HelpFrame extends JFrame {

	private JPanel contentPane;
	
	public static void stan() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HelpFrame frame = new HelpFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}
	
	/**
	 * Create the frame.
	 */
	public HelpFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 507, 420);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblInstructionsForUse = new JLabel("Instructions for use:");
		lblInstructionsForUse.setFont(new Font("SansSerif", Font.BOLD, 16));
		lblInstructionsForUse.setBounds(21, 22, 196, 22);
		contentPane.add(lblInstructionsForUse);
		
		JTextPane txtpnEnsureThat = new JTextPane();
		txtpnEnsureThat.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtpnEnsureThat.setEditable(false);
		txtpnEnsureThat.setText("1. Ensure that all the documents under consideration are palced in a single directory and not in any sub-directories.");
		txtpnEnsureThat.setBounds(31, 63, 408, 41);
		contentPane.add(txtpnEnsureThat);
		
		JTextPane txtpnEnsureThat_1 = new JTextPane();
		txtpnEnsureThat_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtpnEnsureThat_1.setEditable(false);
		txtpnEnsureThat_1.setText("2. Ensure that none of the documents under consideration or reports are open. ");
		txtpnEnsureThat_1.setBounds(31, 115, 408, 41);
		contentPane.add(txtpnEnsureThat_1);
		
		JTextPane txtpnPressThe = new JTextPane();
		txtpnPressThe.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtpnPressThe.setEditable(false);
		txtpnPressThe.setText("3. Click on the Reset button before beginning a new search. ");
		txtpnPressThe.setBounds(31, 167, 408, 22);
		contentPane.add(txtpnPressThe);
		
		JTextPane txtpnOpenReport = new JTextPane();
		txtpnOpenReport.setText("4. Open Report button opens the report.xlsx file, where as filter button displays eligible profiles in the same window.");
		txtpnOpenReport.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtpnOpenReport.setEditable(false);
		txtpnOpenReport.setBounds(31, 200, 408, 41);
		contentPane.add(txtpnOpenReport);
		
		JTextPane txtpnPleaseWait = new JTextPane();
		txtpnPleaseWait.setText("5. Please wait for the report generation messaege to appear beneath the Generate report button before opening or filtering the report.");
		txtpnPleaseWait.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		txtpnPleaseWait.setEditable(false);
		txtpnPleaseWait.setBounds(31, 252, 408, 68);
		contentPane.add(txtpnPleaseWait);
	}

	
}
