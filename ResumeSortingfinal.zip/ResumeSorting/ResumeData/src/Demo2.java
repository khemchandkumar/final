import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

public class Demo2 {

	public static void main(String[] args) throws InvalidFormatException, IOException {
		

		
			
				String[] keys={"java","selenium"};
				System.out.println(keys[1]);
				
				File folder = new File("D:\\prgms");
				File[] listOfFiles = folder.listFiles();
		    	
				
		    	
		        	//Iterate for files inside the folder
		        	for (File file : listOfFiles) {
			    	    if (file.isFile()) {
			    	    	String resumeFile = file.getName();
			    	    	
			    	    	
			    	    	
			    	    	System.out.println("\n++++++"+resumeFile+"+++++++\n");
			    	    	System.out.println(file.getAbsolutePath());
			    	    	FileInputStream fis = new FileInputStream(file.getAbsolutePath());
				 			XWPFDocument xdoc = new XWPFDocument(OPCPackage.open(fis));
				 			//wordcounter
			    	    }
		        	}
				
			
			    	    }
		
			    	    }
	


