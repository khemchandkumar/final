package com.capgemini.presentationtier;

import java.io.FileNotFoundException;
import java.io.PrintStream;

public class SaveOutPutToFile {
	
	public  void printStuff(){
		try{
			PrintStream myconsole = new PrintStream("D://alok.txt");
			System.setOut(myconsole);
			
		
	}catch(FileNotFoundException fx){
		System.out.println(fx);
	}

	}
}
