package com.capgemini.businesstier;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

public class WordReader extends ExcelReader {

	public WordReader() {
		// TODO Auto-generated constructor stub
	}

	public int  wordCounter(XWPFDocument xdoc, String keywor) {
		
		//System.out.println("The keyword this time is \""+keywor+"\"");		
		Iterable<XWPFParagraph> paragraphList = xdoc.getParagraphs();
		int count=1;
		
		for (XWPFParagraph paragraph : paragraphList) {
			
				//System.out.println(paragraph.getText());
				
				String[] words = paragraph.getText().split("\\s+");
				
		 				for (int i = 0; i < words.length; i++) {
		 					words[i] = words[i].replaceAll("[^\\w]", "");
		 				    // You may want to check for a non-word character before blindly
		 				    // performing a replacement it may also be necessary to adjust the character class
		 					 		
		 					if(words[i].equalsIgnoreCase(keywor)){
			 					count++;
		 			}
		 					
		 							 		
					}
		 				
		 	} 
		return count;
		//System.out.println(keywor +" Has appeared "+count +" number of times");
		 		
	}
	
	
	
			
	
	
}
