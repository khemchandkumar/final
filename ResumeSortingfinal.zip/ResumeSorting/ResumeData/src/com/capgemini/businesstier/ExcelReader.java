package com.capgemini.businesstier;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

import com.capgemini.presentationtier.FolderIterator;

public class ExcelReader extends ReportGenerator  {
	public String keyword;
	int rownum;
	//WordReader wr = new WordReader();
	
	public void reader(XWPFDocument mydoc, String fileName){
	try{
		  
			FileInputStream excelFile = new FileInputStream(new File("D:\\prgms\\assist\\keys.xlsx"));
		    
			
			 
		    //Create Workbook instance holding reference to .xlsx file
		    XSSFWorkbook workbook = new XSSFWorkbook(excelFile);
		    
		    //Get first/desired sheet from the workbook
		    XSSFSheet sheet = workbook.getSheetAt(0);
		    int KeyCount = sheet.getLastRowNum()+1;
		    
		
		    //Iterate through each rows one by one
		    Iterator<Row> rowIterator = sheet.iterator();
		    while (rowIterator.hasNext())
		        {
		            Row row = rowIterator.next();
		            //For each row, iterate through all the columns
		            Iterator<Cell> cellIterator = row.cellIterator();
		             
		            while (cellIterator.hasNext())
		            {
		                Cell cell = cellIterator.next();
		                //Check the cell type and format accordingly
		                int type = cell.getCellType();
		                
				                    switch (type)
				                    {
				                        case 0:
				                        	rownum = (int) cell.getNumericCellValue();
				                            //System.out.print(rownum + "\n");
				                           
				                            break;
				                        case 1:
				                        	keyword = cell.getStringCellValue();
				                            //System.out.print(keyword + "\n");
				                            break;
				                    }
				                    
				                   
				                  
            }
		           
		            WordReader wr = new WordReader();
         		    int coun = wr.wordCounter(mydoc, keyword);
         		    System.out.println("\nThe keyword \""+keyword +"\":"+(coun)+" times\n");
         		    String toony = fileName;
         		    ReportGenerator.FillExcel(coun,keyword,rownum, toony , KeyCount);
         		    
            
        }
		   
		
        excelFile.close();
        //return keyword;

}catch (Exception e){
e.printStackTrace();
}
	//return keyword;
	
}

	
}

	

	
	

