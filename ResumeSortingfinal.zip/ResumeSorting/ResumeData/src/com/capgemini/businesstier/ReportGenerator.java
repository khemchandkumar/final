package com.capgemini.businesstier;

import java.io.File;
import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.examples.NewSheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReportGenerator {

	public ReportGenerator() {
		// TODO Auto-generated constructor stub
	}
	
	static XSSFWorkbook workbook = new XSSFWorkbook();
 	// Create a blank sheet
	
    static XSSFSheet sheet = workbook.createSheet("Student Details");	
    
    //static int num = 1;
    static String jon = "Resume1";
    static int rNum = 2;
    static Row row0 = sheet.createRow(0);
    static Row row1 = sheet.createRow(1);
	static Row row2 = sheet.createRow(rNum); 
   
	public static void FillExcel(int ct , String word , int rownum , String toon , int keyCount)
    {
		jon = toon;
			if(jon.equalsIgnoreCase(toon)){
				
					Cell cell0 = row0.createCell(rownum+1);
			        Cell cell1 = row1.createCell(rownum+1);
			        Cell cell2 = row2.createCell(rownum+1);
			        Cell cell3 = row2.createCell(0);
			       
			        cell0.setCellValue(rownum);
			        cell1.setCellValue(word);
			        cell2.setCellValue(ct);
			        cell3.setCellValue(toon);
			        
			        
			}else{
				Row row2 = sheet.createRow(rNum+2); 
				Cell cell0 = row0.createCell(rownum+1);
		        Cell cell1 = row1.createCell(rownum+1);
		        Cell cell2 = row2.createCell(rownum+1);
		        Cell cell3 = row2.createCell(0);
		       
		        cell0.setCellValue(rownum);
		        cell1.setCellValue(word);
		        cell2.setCellValue(ct);
		        cell3.setCellValue(toon);
			}
			
				
		
			
		
		 	 
			
		    /* Row row0 = sheet.createRow(0);
		     Row row1 = sheet.createRow(1);
			 Row row2 = sheet.createRow(rNum); 
		
			Cell cell0 = row0.createCell(rownum+1);
	        Cell cell1 = row1.createCell(rownum+1);
	        Cell cell2 = row2.createCell(rownum+1);
	        Cell cell3 = row2.createCell(0);
	       
	        cell0.setCellValue(rownum);
	        cell1.setCellValue(word);
	        cell2.setCellValue(ct);
	        cell3.setCellValue(toon);*/
        	
	        try {
	           
		            FileOutputStream out = new FileOutputStream(new File("D:\\prgms\\assist\\report.xlsx"));
		            workbook.write(out);
		            out.close();
	           
		        }
		        	catch (Exception e) {
		            e.printStackTrace();
		        }
    }

	

}
