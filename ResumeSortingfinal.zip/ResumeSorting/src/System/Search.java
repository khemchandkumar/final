package System;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JTextPane;

public class Search extends Keywords{
	public String fileName;
	private JFrame frmKeywords;
	private JTextField keywords1;
	private JTextField howmany;
	private JTextField keywords5;
	private JTextField keywords2;
	private JTextField keywords6;
	private JTextField keywords3;
	private JTextField keywords7;
	private JTextField keywords4;
	private JTextField keywords8;
	private JTextField keywords9;
	private JTextField keywords10;
	private JTextField keywords11;
	private JTextField keywords12;
	private JTextField report;
	private JTextField textField;
	private JButton btnGetDirectory;

	/**
	 * Launch the application.
	 */
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Search window = new Search();
					window.frmKeywords.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Search() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	private void initialize() {
		
		frmKeywords = new JFrame();
		frmKeywords.setTitle("keywords");
		frmKeywords.setBackground(Color.MAGENTA);
		frmKeywords.setBounds(100, 100, 450, 300);
		frmKeywords.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmKeywords.getContentPane().setLayout(null);
		
		JLabel lblKeywords = new JLabel("Keywords");
		lblKeywords.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblKeywords.setBounds(131, 11, 210, 31);
		frmKeywords.getContentPane().add(lblKeywords);
		
		JLabel lblHowMany = new JLabel("How many?");
		lblHowMany.setFont(new Font("Tamal", Font.PLAIN, 15));
		lblHowMany.setBounds(25, 48, 86, 25);
		frmKeywords.getContentPane().add(lblHowMany);
		
		JLabel lblEnterTheKeywords = new JLabel("Enter the Keywords below :");
		lblEnterTheKeywords.setBounds(25, 84, 327, 25);
		frmKeywords.getContentPane().add(lblEnterTheKeywords);
		
		keywords1 = new JTextField();
		keywords1.setBounds(25, 120, 86, 20);
		frmKeywords.getContentPane().add(keywords1);
		keywords1.setColumns(10);
		
		btnGetDirectory = new JButton("Get Directory");
		btnGetDirectory.addActionListener(new ActionListener() {
			
				
				public void actionPerformed(ActionEvent arg0) {
					JFileChooser fc=new JFileChooser();
					fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					//int response=fc.showOpenDialog(DirectoriesOnly.this);
					if(fc.showOpenDialog(null)==JFileChooser.APPROVE_OPTION)
					textField.setText(fc.getSelectedFile().toString());
					fileName=fc.getSelectedFile().toString();
				
				}
		});
		btnGetDirectory.setBounds(268, 51, 89, 23);
		frmKeywords.getContentPane().add(btnGetDirectory);
		
		
		
		
		
		JButton btnOk = new JButton("Ok");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String[] Keys= {keywords1.getText(),keywords2.getText(),keywords3.getText(),keywords4.getText(),keywords5.getText(),keywords6.getText(),
						keywords7.getText(),keywords8.getText(),keywords9.getText(),keywords10.getText(),keywords11.getText(),
						keywords12.getText()};
				
				
				int many = Integer.parseInt(howmany.getText());
	            report.setText("REPORT generated. close");
	            String addresss=(fileName);
	            
				FolderIterator.start(Keys,many,addresss);
				
			}
		});
		
		btnOk.setBounds(182, 233, 89, 23);
		frmKeywords.getContentPane().add(btnOk);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				keywords1.setText(null);
				howmany.setText(null);
			}
		});
		btnReset.setBounds(304, 233, 89, 23);
		frmKeywords.getContentPane().add(btnReset);
		
		howmany = new JTextField();
		howmany.setBounds(121, 52, 86, 20);
		frmKeywords.getContentPane().add(howmany);
		howmany.setColumns(10);
		
		keywords5 = new JTextField();
		keywords5.setBounds(25, 151, 86, 20);
		frmKeywords.getContentPane().add(keywords5);
		keywords5.setColumns(10);
		
		keywords2 = new JTextField();
		keywords2.setBounds(131, 120, 86, 20);
		frmKeywords.getContentPane().add(keywords2);
		keywords2.setColumns(10);
		
		keywords6 = new JTextField();
		keywords6.setBounds(131, 151, 86, 20);
		frmKeywords.getContentPane().add(keywords6);
		keywords6.setColumns(10);
		
		keywords3 = new JTextField();
		keywords3.setColumns(10);
		keywords3.setBounds(242, 120, 86, 20);
		frmKeywords.getContentPane().add(keywords3);
		
		keywords7 = new JTextField();
		keywords7.setColumns(10);
		keywords7.setBounds(242, 151, 86, 20);
		frmKeywords.getContentPane().add(keywords7);
		
		keywords4 = new JTextField();
		keywords4.setColumns(10);
		keywords4.setBounds(338, 120, 86, 20);
		frmKeywords.getContentPane().add(keywords4);
		
		keywords8 = new JTextField();
		keywords8.setColumns(10);
		keywords8.setBounds(338, 151, 86, 20);
		frmKeywords.getContentPane().add(keywords8);
		
		keywords9 = new JTextField();
		keywords9.setColumns(10);
		keywords9.setBounds(25, 182, 86, 20);
		frmKeywords.getContentPane().add(keywords9);
		
		keywords10 = new JTextField();
		keywords10.setColumns(10);
		keywords10.setBounds(131, 182, 86, 20);
		frmKeywords.getContentPane().add(keywords10);
		
		keywords11 = new JTextField();
		keywords11.setColumns(10);
		keywords11.setBounds(242, 185, 86, 20);
		frmKeywords.getContentPane().add(keywords11);
		
		keywords12 = new JTextField();
		keywords12.setColumns(10);
		keywords12.setBounds(338, 182, 86, 20);
		frmKeywords.getContentPane().add(keywords12);
		
		report = new JTextField();
		report.setBounds(25, 234, 147, 20);
		frmKeywords.getContentPane().add(report);
		report.setColumns(10);
		
		textField = new JTextField();
		textField.setBounds(223, 86, 189, 20);
		frmKeywords.getContentPane().add(textField);
		textField.setColumns(10);
		
		
		
	}

	
}
