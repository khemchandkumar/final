package System;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Keywords {

	private JFrame frame;
	public static String address;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Keywords window = new Keywords();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Keywords() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(200, 300, 600, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblResumeSortingSystem_1 = new JLabel("Resume Sorting System");
		lblResumeSortingSystem_1.setFont(new Font("Tahoma", Font.PLAIN, 36));
		lblResumeSortingSystem_1.setBounds(91, 25, 376, 44);
		frame.getContentPane().add(lblResumeSortingSystem_1);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Search search=new Search();
			
						
				Search.main(null);
				
				//initiate the search action from the folder iterator
				//FolderIterator.main(null);
			}
		});
		btnNewButton.setBounds(76, 282, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Help");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				help hp=new help();
				hp.show();
			}
		});
		btnNewButton_1.setBounds(243, 282, 89, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
				
			}

			
		});
		btnExit.setBounds(425, 282, 89, 23);
		frame.getContentPane().add(btnExit);
		
		JLabel lblInstructionsForUse = new JLabel("Instructions for use");
		lblInstructionsForUse.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblInstructionsForUse.setBounds(77, 97, 292, 23);
		frame.getContentPane().add(lblInstructionsForUse);
		
		JLabel lblKindlyMake = new JLabel("1. Kindly make an Excel workbook with name report in E:\\prgms\\assist");
		lblKindlyMake.setBounds(76, 131, 438, 27);
		frame.getContentPane().add(lblKindlyMake);
		
		JLabel lblCreateA = new JLabel("2. Create a sheet with name \"Keyword Details\"");
		lblCreateA.setBounds(76, 158, 351, 23);
		frame.getContentPane().add(lblCreateA);
		
		JLabel lblBeforeRunning = new JLabel("3. Before running the Jar Executable, kindly clear the sheet.");
		lblBeforeRunning.setBounds(76, 180, 351, 27);
		frame.getContentPane().add(lblBeforeRunning);
		
		
		
		
		//if(response==JFileChooser.APPROVE_OPTION) {
			
		//}
	}
}
