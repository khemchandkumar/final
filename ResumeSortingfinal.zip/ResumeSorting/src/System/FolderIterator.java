package System;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Scanner;

import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

public class FolderIterator {
	
	
	
public static int  wordCounter(XWPFDocument xdoc, String keyword) {
		
		//System.out.println("The keyword this time is \""+keywor+"\"");		
		Iterable<XWPFParagraph> paragraphList = xdoc.getParagraphs();
		int count=0;
		
		for (XWPFParagraph paragraph : paragraphList) {
			
				//System.out.println(paragraph.getText());
				
				String[] words = paragraph.getText().split("\\s+");
				
		 				for (int i = 0; i < words.length; i++) {
		 					//words[i] = words[i].replaceAll("[^\\w]", "");
		 				  	if(words[i].equalsIgnoreCase(keyword)){
			 					count++;
		 			}
		 					 						 		
					}
		 				
		 	} 
		wordcount=count;
		return count;
	
}
	
//static int n = 2;	
static int wordcount;

	
	public static void start(String[] keys,int many,String address) {
		
		//System.out.println();
		
		
		
	//System.out.println("Enter the number of keywords you want to search");	
	//Scanner scan=new Scanner(System.in);
	 //n=scan.nextInt();
		
		
	System.out.println("You have entered main of FolderIterator");
	
	
	System.out.println("Enter the keywords ");	
	
		
		File folder = new File(address); //ALL DOCX RESUME FILES 
    	File[] listOfFiles = folder.listFiles();
    	
		
    	try
        {
        	int j=0;
    		//Iterate for files inside the folder
        	for (File file : listOfFiles) {
	    	    if (file.isFile()) {
	    	    	String resumeFile = file.getName();
	    	    	System.out.println("\n++++++"+resumeFile+"+++++++\n");
	    	    	
	    	    	FileInputStream fis = new FileInputStream(file.getAbsolutePath());
		 			XWPFDocument xdoc = new XWPFDocument(OPCPackage.open(fis));
		 			excelwriterfilename(resumeFile);
		 			
		 			
		 			
		 			int counter[]=new int[many]; 
		 			for(int i=0;i<many;i++){
		 			System.out.println(wordCounter(xdoc, keys[i]));
		 			counter[i]=wordCounter(xdoc, keys[i]);
		 			excelwriterkeyword(keys,many);
		 			
		 			
		 			excelwritercount(counter[i],i+1,j+1);
		 			
		 			}
	    	
		 			j++;
		 		}
        	}
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        	

	}



public static void excelwriterkeyword(String keys[],int n) throws IOException{

	
FileInputStream fiis=new FileInputStream(new File("E:\\prgms\\assist\\report.xlsx"));
XSSFWorkbook workbook = new XSSFWorkbook(fiis);
XSSFSheet sheet = workbook.getSheet("Keyword Details");	
Row row0 = sheet.createRow(0);		

for(int i=0;i<n;i++){
	Cell cell=row0.createCell(i+1);
	cell.setCellValue(keys[i]);
		       
}	        

        try {
           
	            FileOutputStream out = new FileOutputStream(new File("E:\\prgms\\assist\\report.xlsx"));
	            workbook.write(out);
	            out.close();
           
	        }
	        	catch (Exception e) {
	            e.printStackTrace();
	        }
}



static int rownum=1;
public static void excelwriterfilename(String resumefile) throws IOException{
	
	
	FileInputStream fiis=new FileInputStream(new File("E:\\prgms\\assist\\report.xlsx"));
	XSSFWorkbook workbook = new XSSFWorkbook(fiis);
	XSSFSheet sheet = workbook.getSheet("Keyword Details");	
	//getting the sheet around 
	
	
	Row row0=sheet.createRow(rownum);
	//Row row0 = sheet.createRow(sheet.getLastRowNum()+1);	
	Cell cell=row0.createCell(0);
	cell.setCellValue(resumefile);
	rownum++;
        try {
           
	            FileOutputStream out = new FileOutputStream(new File("E:\\prgms\\assist\\report.xlsx"));
	            workbook.write(out);
	            out.close();
	           
           
	        }
	        	catch (Exception e) {
	            e.printStackTrace();
	        }
}

public static void excelwritercount(int countvalue,int colnum,int rownumm) throws IOException{

	
FileInputStream fiis=new FileInputStream(new File("E:\\prgms\\assist\\report.xlsx"));
XSSFWorkbook workbook = new XSSFWorkbook(fiis);
XSSFSheet sheet = workbook.getSheet("Keyword Details");	
Row row0 = sheet.getRow(rownumm);		


	Cell cell=row0.createCell(colnum);
	cell.setCellValue(countvalue);
		       
        

        try {
           
	            FileOutputStream out = new FileOutputStream(new File("E:\\prgms\\assist\\report.xlsx"));
	            workbook.write(out);
	            out.close();
           
	        }
	        	catch (Exception e) {
	            e.printStackTrace();
	        }
}


}